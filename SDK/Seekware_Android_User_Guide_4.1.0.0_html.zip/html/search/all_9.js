var searchData=
[
  ['kelvin_100',['KELVIN',['../enumcom_1_1thermal_1_1seekware_1_1_seek_utility_1_1_temperature_1_1_unit.html#af511ad7b122173d17ab7df2b62300a41',1,'com::thermal::seekware::SeekUtility::Temperature::Unit']]]
];
