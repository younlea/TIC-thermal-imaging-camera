var searchData=
[
  ['prism_395',['PRISM',['../enumcom_1_1thermal_1_1seekware_1_1_seek_camera_1_1_color_lut.html#a7132db0eed322234e2152defbbc44765',1,'com::thermal::seekware::SeekCamera::ColorLut']]]
];
