var searchData=
[
  ['permission_217',['Permission',['../enumcom_1_1thermal_1_1seekware_1_1_seek_utility_1_1_permission_handler_1_1_permission.html',1,'com::thermal::seekware::SeekUtility::PermissionHandler']]],
  ['permissionhandler_218',['PermissionHandler',['../classcom_1_1thermal_1_1seekware_1_1_seek_utility_1_1_permission_handler.html',1,'com::thermal::seekware::SeekUtility']]]
];
