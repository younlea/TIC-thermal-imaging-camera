var searchData=
[
  ['new_5fimage_388',['NEW_IMAGE',['../enumcom_1_1thermal_1_1seekware_1_1_seek_camera_1_1_memory_region.html#ae80bc52bba95a695593fce2fc3226648',1,'com::thermal::seekware::SeekCamera::MemoryRegion']]],
  ['none_389',['NONE',['../classcom_1_1thermal_1_1seekware_1_1_seek_logger.html#a93d37a8a0f155b4d18af9d9bd9ee813f',1,'com::thermal::seekware::SeekLogger']]]
];
