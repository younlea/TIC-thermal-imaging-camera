var searchData=
[
  ['previous_327',['previous',['../enumcom_1_1thermal_1_1seekware_1_1_seek_camera_1_1_orientation.html#a981f9503a4cc61fcf73a8396193deedf',1,'com::thermal::seekware::SeekCamera::Orientation']]]
];
