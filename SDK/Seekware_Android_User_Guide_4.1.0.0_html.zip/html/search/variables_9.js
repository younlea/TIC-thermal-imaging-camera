var searchData=
[
  ['match_5fheight_386',['MATCH_HEIGHT',['../enumcom_1_1thermal_1_1seekware_1_1_seek_camera_1_1_aspect_ratio.html#a9e8a2ea6dbf6989e65ba82083edac7fd',1,'com::thermal::seekware::SeekCamera::AspectRatio']]],
  ['match_5fwidth_387',['MATCH_WIDTH',['../enumcom_1_1thermal_1_1seekware_1_1_seek_camera_1_1_aspect_ratio.html#afdb6c12b3af77d001f16080f18865ee1',1,'com::thermal::seekware::SeekCamera::AspectRatio']]]
];
